Route bundle exported by Kestrel 2.3. Contains one GPX track.
